<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
 .tippy-tooltip.tool-theme {
  /* Your styling here. Example: */
  font-size: 10px;
  width: 70px;
 }
</style>
