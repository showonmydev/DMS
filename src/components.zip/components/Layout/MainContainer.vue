<template>
<drop @drop="divOuter">
<div class="content-wrapper" id="resizable">
<div class="table-content">
  <div class="table-head clearfix">
    <div class="pull-left tbl-title"> {{ tablegroup }} / </div>
    &nbsp; &nbsp;<button type="button" class="btn btn-info tbl_callSetting" @click="showHideColumn('openModal')">Show/Hide</button>
    <div class="pull-right">1 Row Selected</div>
  </div>
  <div class="container-fluid">
        <div class="demo-content">
    <drop @drop="drop" @dragover="handleDragover" @dragleave="handledragleave">
      <table id="footerTable" class="sar-table ui-widget-content table table-bordered">
        <thead>
            <tr><th><div class="checkbox"><label><input type="checkbox" value=""><span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span></label></div>              </th>
                <th v-if="column.name">Name</th>
                <th v-if="column.model">Model</th>
                <th v-if="column.type">Type</th>
                <th v-if="column.group">Group</th>
                <th v-if="column.mcaAddress">MCA Add.</th>
                <th v-if="column.ipAddress">IP Add.</th>
                <th v-if="column.serial">Serial</th>
                <th v-if="column.version">Version</th>
            </tr>
        </thead>
        <tbody>
            <tr v-for="(data, key) in tableData" v-bind:key="key">
                <td><div class="checkbox" @click="getDeviceInfo(key)"><label><input type="checkbox" value=""><span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span></label></div></td>
                <td v-if="column.name">{{data.name}}</td>
                <td v-if="column.model">{{data.model}}</td>
                <td v-if="column.type">{{data.type}}</td>
                <td v-if="column.group">{{data.group}}</td>
                <td v-if="column.mcaAddress">{{data.MACAddress}}</td>
                <td v-if="column.ipAddress">{{data.IPAddress}}</td>
                <td v-if="column.serial">{{data.SerialNumber}}</td>
                <td v-if="column.version">{{data.Version}}</td>
            </tr>
            <tr v-if="hover" style="background-color:gray;color:white">
                <td><div class="checkbox"><label><input type="checkbox" value=""><span class="cr"><i class="cr-icon glyphicon glyphicon-ok"></i></span></label></div></td>
                <td v-if="column.name">{{DroptableData.name}}</td>
                <td v-if="column.model">{{DroptableData.model}}</td>
                <td v-if="column.type">{{DroptableData.type}}</td>
                <td v-if="column.group">{{DroptableData.group}}</td>
                <td v-if="column.mcaAddress">{{DroptableData.MACAddress}}</td>
                <td v-if="column.ipAddress">{{DroptableData.IPAddress}}</td>
                <td v-if="column.serial">{{DroptableData.SerialNumber}}</td>
                <td v-if="column.version">{{DroptableData.Version}}</td>
            </tr>
        </tbody>
      </table>
    </drop>
    </div>
    <div class="modal-ShowHide">
    <modal name="show-hide-column">
          <header class="modal-header">
            <slot name="header">
           <h4>Show/Hide Column
              <button type="button" class="btn btn-close" @click="close"><i class="fa fa-times"></i></button>
          </h4>  </slot>
          </header>
          <section class="modal-body row col-md-12">
            <slot name="body">
                    <div class="col-md-6">
                        <input type="checkbox" id="name-checkbox" v-if="(column.name ? 'true':'false')" @click="checkState('name',column.name)"  v-model="column.name">
                        <label>Name</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="model-checkbox" v-if="(column.model ? 'true':'false')" @click="checkState('model',column.model)" v-model="column.model">
                        <label>Model</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="type-checkbox" v-if="(column.type ? 'true':'false')" @click="checkState('type',column.type)" v-model="column.type">
                        <label>Type</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="group-checkbox" v-if="(column.group ? 'true':'false')" @click="checkState('group',column.group)" v-model="column.group">
                        <label>Group</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="mcaAddress-checkbox" v-if="(column.mcaAddress ? 'true':'false')" @click="checkState('mcaAddress',column.mcaAddress)" v-model="column.mcaAddress">
                        <label>MCA Add.</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="ipAddress-checkbox" v-if="(column.ipAddress ? 'true':'false')" @click="checkState('ipAddress',column.ipAddress)" v-model="column.ipAddress">
                        <label>IP Address</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="serial-checkbox" v-if="(column.serial ? 'true':'false')" @click="checkState('serial',column.serial)" v-model="column.serial">
                        <label>Serial</label>
                    </div>
                    <div class="col-md-6">
                        <input type="checkbox" id="version-checkbox" v-if="(column.version ? 'true':'false')" @click="checkState('version',column.version)" v-model="column.version">
                        <label>Version</label>
                    </div>
            </slot>
          </section>
          <footer class="modal-footer">
              <slot name="footer">
                <button type="button" class="btn-default btn" @click="close">Cancel</button>
            </slot>
          </footer>
      </modal>
      </div>
    </div>
</div>
</div>
</drop>
</template>
<!-- built files will be auto injected -->
<script>
export default {
  props: [ 'tablegroup', 'tablegroupid', 'clickTarget' ],
  name: 'HelloWorld',
  data () {
    return {
      // tableData: [{'name': 'text', 'model': 'text', 'type': 'text', 'group': 'text', 'MACAddress': 'text', 'IPAddress': 'text', 'SerialNumber': 'text', 'Version': 'text'}],
      multipleSelection: [],
      hover: false,
      checkIfOutsideDrop: true
    }
  },
  computed: {
    column: function () {
      return this.$store.state.Setting.showHideColumn
    },
    tableData: function () {
      this.checkIfOutsideDrop = 'true'
      return this.$store.state.Setting.DisplayTableData
    },
    DroptableData: function () {
      return this.$store.state.Setting.DragdropContainer.list
    }
  },
  methods: {
    dragStart (event) {
      event.dataTransfer.setData('Text', event.target.id)
    },
    handleSelectionChange (val) {
      this.multipleSelection = val
      this.$emit('emitTableRowClick', this.multipleSelection)
    },
    handleCurrentChange (val) {
      this.multipleSelection = ['0', val]
      this.$emit('emitTableRowClick', this.multipleSelection)
      this.$refs.singleTable.clearSelection()
      this.$refs.singleTable.toggleRowSelection(val)
    },
    checkState (field, val) {
      let fieldVal
      if (val === true) {
        fieldVal = false
      } else {
        fieldVal = true
      }
      this.$store.commit('ShowHideDetails', {key: field, value: fieldVal})
    },
    showHideColumn () {
      this.$modal.show('show-hide-column')
    },
    close () {
      this.$modal.hide('show-hide-column')
    },
    drop (event, data) {
      let containerParentKey = this.$store.state.Setting.GetParentKey.parentnode
      this.$store.commit('AppendDataIntoActualPlace', containerParentKey)
      this.hover = false
      this.checkIfOutsideDrop = false
    },
    divOuter () {
      if (this.checkIfOutsideDrop) {
        console.log('fgdh')
        this.$store.commit('RecoverTableSchemaDropOtherSide')
        this.checkIfOutsideDrop = false
      }
    },
    handleDragover () {
      if (!this.hover) {
        this.hover = true
      }
    },
    handledragleave () {
       if (this.hover) {
        this.hover = false
      } 
    },
    getDeviceInfo (key) {
      this.$store.commit('GetDeviceFullInfo', this.tableData[key])
    }
  }
}
</script>
<style>
.content-wrapper .el-table {
    overflow-x: scroll
}
.content-wrapper .el-table__footer-wrapper, .content-wrapper .el-table__header-wrapper {
    overflow: visible
}
.content-wrapper .el-table__body-wrapper {
    overflow: visible
}
.table-head {
    padding: 10px
}
#Table_azam {
    display: table;
    width:100%;
}
#Title_azam {
    display: table-caption;
    text-align: center;
    font-weight: bold;
    font-size: larger;
}
#Heading_azam {
    display: table-row;
    /* font-weight: bold; */
    text-align: center;
    background: #f5f5f5;
    color: #080808;
    font-size: 16px;
}
#Row_azam {
    display: table-row;
}
#Cell_azam {
    display: table-cell;
    border: 0.222em solid #020202;
    border-width: thin;
    padding-left: 5px;
    padding-right: 5px;
}
#content_azam{
    padding-top: 8px;
    text-align:center;
}
#head_azam{
    padding-top: 8px;
}
.scroll-azam{overflow-x:scroll; padding-left: 0px; padding-right: 0px;}
/*Radio and Checkbox START*/
.checkbox label:after, .radio label:after {
    content: '';
    display: table;
    clear: both;
}

.checkbox .cr,
.radio .cr {
    position: relative;
    display: inline-block;
    border: 1px solid #a9a9a9;
    border-radius: .25em;
    width: 1.3em;
    height: 1.3em;
    float: left;
    margin-right: .5em;
}
.radio .cr {
    border-radius: 50%;
}
.checkbox .cr .cr-icon,
.radio .cr .cr-icon {
    position: absolute;
    font-size: .8em;
    line-height: 0;
    top: 50%;
    left: 20%;
}
.checkbox label input[type="checkbox"],
.radio label input[type="radio"] {
    display: none;
}
.checkbox label input[type="checkbox"] + .cr > .cr-icon,
.radio label input[type="radio"] + .cr > .cr-icon {
    transform: scale(3) rotateZ(-20deg);
    opacity: 0;
    transition: all .3s ease-in;
}
.checkbox label input[type="checkbox"]:checked + .cr > .cr-icon,
.radio label input[type="radio"]:checked + .cr > .cr-icon {
    transform: scale(1) rotateZ(0deg);
    opacity: 1;
}

.checkbox label input[type="checkbox"]:disabled + .cr,
.radio label input[type="radio"]:disabled + .cr {
    opacity: .5;
}
</style>
